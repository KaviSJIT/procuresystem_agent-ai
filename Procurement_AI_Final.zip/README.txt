
AGENTIC AI-BASED INTELLIGENT PROCUREMENT MANAGEMENT SYSTEM
============================================================

PROJECT OVERVIEW
----------------
An AI-assisted procurement management prototype for construction
procurement.

SYSTEM PIPELINE
---------------
1. Procurement Dataset
2. Data Preprocessing
3. XGBoost Award Prediction
4. Random Forest Risk Classification
5. FAISS + Sentence Transformer RAG
6. Compliance Evidence Retrieval
7. Decision Engine
8. Human Approval
9. Audit Logging

MACHINE LEARNING
----------------
XGBoost:
- Purpose: Award value prediction
- Target: total_award_value
- Target transformation: log1p

Random Forest:
- Purpose: Procurement risk classification
- Risk classes: LOW, MEDIUM, HIGH
- Risk labels are engineered/proxy labels for prototype evaluation.

RAG
---
Embedding model:
all-MiniLM-L6-v2

FAISS:
- Index type: IndexFlatL2
- Embedding dimension: 384
- RAG tender documents: 3778

COMPLIANCE EVIDENCE
-------------------
The system searches procurement documents for:

1. Permanent Account Number
2. Registration Certificate
3. Bid Affidavit
4. Work Completed Certificate

FINAL PIPELINE TEST
-------------------
Tenders tested: 10

Risk distribution:
LOW: 4
MEDIUM: 3
HIGH: 3

Decision distribution:
Recommended for Human Approval: 4
Manual Review Required: 3
High Risk Review: 3

Average risk confidence: 89.57%
Average compliance evidence: 100%
Average processing time: 0.3128 seconds

IMPORTANT NOTE
--------------
Compliance percentage represents evidence found in the procurement
knowledge base. It does not prove legal or contractual compliance.

The Random Forest risk labels are engineered/proxy labels and
should not be interpreted as real-world validated risk detection.

Final procurement decisions require human review and approval.
